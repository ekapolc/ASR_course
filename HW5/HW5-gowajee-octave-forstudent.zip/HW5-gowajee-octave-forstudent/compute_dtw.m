function [distance] = compute_dtw(template,test)
    %Given input template and test
    %Compute the dtw distance

end
